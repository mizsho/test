---
name: ❓ Support Question
about: Here you can ask questions about the features
labels: help-wanted

---
<!-- Before you ask please check if you can find a similar issue and/or a solution on a issue or on stackoverflow -->

**Description**  
<!-- Description of your support question. -->

**Example (optional)**  
<!-- Please use our online Editor (https://live.bootstrap-table.com/) to create a example (what you already tried).
     On our Wiki (https://github.com/wenzhixin/bootstrap-table/wiki/Online-Editor-Explanation) you can read how to use the editor.-->


<!-- Love bootstrap-table? Please consider supporting our collective:
👉  https://opencollective.com/bootstrap-table/donate -->